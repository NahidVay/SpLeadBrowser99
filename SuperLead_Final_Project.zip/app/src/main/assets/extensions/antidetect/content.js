(function() {
    // Advanced Fingerprint Spoofing
    Object.defineProperty(navigator, 'webdriver', {get: () => false});
    Object.defineProperty(navigator, 'deviceMemory', {get: () => 8});
    Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 8});
    console.log("Anti-Detect Active");
})();