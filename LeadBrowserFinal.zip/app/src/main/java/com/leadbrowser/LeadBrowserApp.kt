package com.leadbrowser

import android.app.Application

class LeadBrowserApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}