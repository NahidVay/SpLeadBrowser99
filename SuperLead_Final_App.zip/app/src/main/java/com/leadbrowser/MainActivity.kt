package com.leadbrowser
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Text
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val runtime = GeckoRuntime.create(this)
            val session = GeckoSession()
            session.open(runtime)
            setContent { Text("SuperLead Browser Ready!") }
        } catch (e: Exception) {
            setContent { Text("Error: " + e.message) }
        }
    }
}